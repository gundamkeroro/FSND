In your terminal, change directory to where you extract the file, you should have python2.7 installed and run:

python entertainment_center.py

this command will create a html file, that is what you can open in browser.